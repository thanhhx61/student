﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StudentManagement.Models
{
    public class MessageUpdateViewModel
    {
        public int MessageId { get; set; }
        public string Content { get; set; }
    }
}
