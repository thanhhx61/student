﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StudentManagement.Enums
{
    public enum EventStatus
    {
        UnVerify = 1,
        Verifying = 2,
        Verified = 3
    }
}
